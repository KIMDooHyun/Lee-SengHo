##Support
---
This is an open source project, freely available on [GitHub](https://github.com/jarvisteach/appJar)
Any issues/bugs should be raised on the project's [Issues Page](https://github.com/jarvisteach/appJar/issues)

The code on GitHub will always be the most up-to-date.  
If you want to update your existing code, just replace the [appjar.py file](https://raw.githubusercontent.com/jarvisteach/appJar/appJar/appjar.py)   
Zip files are available to download from the [releases folder](https://github.com/jarvisteach/appJar/tree/appJar/releases)  
