##License
---
This project has been a labour of love over the last couple of years.  

When confronted with the difficulty both pupils and teachers were having creating simple GUIs with Python, I started out trying to put together a few helper functions to make life simpler.  

It's obviously grown a bit since then, and has become fairly functional!  

appJar is released under the [GNU General Public License](http://www.gnu.org/licenses/gpl.html) 

So, you're free to use it, modify it & redistribute it, as long as you acknowledge my copyright, and aren't trying to make money out of it...  
