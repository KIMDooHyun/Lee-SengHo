from appJar import gui

app=gui()
app.setFont(20)
app.setBg("lightBlue")
app.addSeparator(colour="red")
app.go()
