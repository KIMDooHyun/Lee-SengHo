from appJar import gui

app=gui()

app.addScrolledTextArea("t1")

app.go()
